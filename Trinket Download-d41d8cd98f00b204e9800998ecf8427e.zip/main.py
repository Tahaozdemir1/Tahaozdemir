opChoice = input("Was ist ihre Auswahl?\n[1]Addition\n[2]Substraktion\n[3]Multiplikation\n[4]Division\nAuswahl: ")

def Addition(num1, num2):
    return num1 + num2

def Substraktion(num1, num2):
    return num1 - num2

def Multiplikation(num1, num2):
    return num1 * num2

def Division(num1, num2):
    if num2 == 0:
        return "Division durch Null ist nicht erlaubt."
    return num1 / num2

# Menü auswählen
if opChoice == "1":
    num1 = int(input("Erste Zahl? "))
    num2 = int(input("Zweite Zahl? "))
    print(f"{num1} + {num2} = {Addition(num1, num2)}")

elif opChoice == "2":
    num1 = int(input("Erste Zahl? "))
    num2 = int(input("Zweite Zahl? "))
    print(f"{num1} - {num2} = {Substraktion(num1, num2)}")

elif opChoice == "3":
    num1 = int(input("Erste Zahl? "))
    num2 = int(input("Zweite Zahl? "))
    print(f"{num1} * {num2} = {Multiplikation(num1, num2)}")

elif opChoice == "4":
    num1 = int(input("Erste Zahl? "))
    num2 = int(input("Zweite Zahl? "))
    print(f"{num1} / {num2} = {Division(num1, num2)}")

else:
    print("Ungültige Auswahl.")
    
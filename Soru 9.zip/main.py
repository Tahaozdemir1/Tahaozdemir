metin = input("Metni girin: ")
harf = input("Silinecek harfi girin: ")

print(metin.replace(harf, ""))
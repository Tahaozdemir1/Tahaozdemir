kelime = input("Kelime: ")
indeks = int(input("Sayı: "))
harf = input("Harf: ")

if indeks < len(kelime):
    kelime = kelime[:indeks] + harf + kelime[indeks+1:]
    print("Yeni kelime:", kelime)
else:
    print("İndeks kelimenin dışında!")
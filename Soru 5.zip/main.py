k = input("Sözcük: ")
s = int(input("Sayı: "))
print(k[:s] + "-" + k[s:])
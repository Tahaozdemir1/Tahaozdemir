metin = input("Bir metin girin: ")
sozcuk = input("Bir sözcük girin: ")

for harf in sozcuk:
    metin = metin.replace(harf, "")

print(metin)
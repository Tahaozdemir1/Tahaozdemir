kelime = input("Bir Sözcük yaz: ")
print(len(kelime))

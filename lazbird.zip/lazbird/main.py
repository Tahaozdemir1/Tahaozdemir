import pygame
import sys
import random
import time
import os

pygame.init()
os.environ['SDL_VIDEODRIVER'] = 'x11'

# Ekran boyutu
GENISLIK, YUKSEKLIK = 600, 800
ekran = pygame.display.set_mode(
    (GENISLIK, YUKSEKLIK), pygame.DOUBLEBUF | pygame.HWSURFACE | pygame.SCALED)
pygame.display.set_caption("LazBird")

# Özel ikon oluştur
ikon_boyut = 32
ikon_yuzey = pygame.Surface((ikon_boyut, ikon_boyut))
ikon_yuzey.fill((255, 255, 255))  # Beyaz arka plan
pygame.draw.circle(ikon_yuzey, (255, 0, 0), (ikon_boyut // 2, ikon_boyut // 2),
                   ikon_boyut // 2)  # Kırmızı daire
pygame.display.set_icon(ikon_yuzey)

saat = pygame.time.Clock()
pygame.event.set_allowed([pygame.QUIT, pygame.KEYDOWN])

# Renkler
BEYAZ = (255, 255, 255)
SIYAH = (0, 0, 0)
YESIL = (0, 200, 0)
KIRMIZI = (255, 0, 0)

# Kuş özellikleri
kus_x = 50
kus_y = YUKSEKLIK // 2
kus_hizi = 0
yercekimi = 0.6
zipla_gucu = -10
kus_genislik = 40
kus_yukseklik = 40

# Kuş görseli - özel çizim
kus_resmi = pygame.Surface((kus_genislik, kus_yukseklik), pygame.SRCALPHA)
pygame.draw.circle(kus_resmi, (255, 165, 0),
                   (kus_genislik // 2, kus_yukseklik // 2),
                   kus_genislik // 2)  # Turuncu gövde
pygame.draw.circle(kus_resmi, (255, 0, 0),
                   (kus_genislik - 10, kus_yukseklik // 2 - 5),
                   5)  # Kırmızı göz
pygame.draw.polygon(kus_resmi, (255, 140, 0),
                    [(kus_genislik - 5, kus_yukseklik // 2),
                     (kus_genislik + 5, kus_yukseklik // 2 - 5),
                     (kus_genislik + 5, kus_yukseklik // 2 + 5)])  # Gaga

# Boru ayarları
boru_genislik = 60
boru_bosluk = 150
boru_hizi = 4

# Başlangıçta 1 boru
borular = [{
    "x": GENISLIK,
    "y": random.randint(50, YUKSEKLIK - boru_bosluk - 100),
    "skor_alindi": False
}]

# Oyun durumu
oyun_bitti = False
oyun_basladi = False
skor = 0

# Yazı tipi
yazi_tipi = pygame.font.SysFont(None, 74)
kucuk_yazi = pygame.font.SysFont(None, 36)

# Sesler (isteğe bağlı)
# zipla_sesi = pygame.mixer.Sound("flap.wav")
# carpma_sesi = pygame.mixer.Sound("hit.wav")


def kusu_ciz(y, hiz):
    donus = -hiz * 2  # Yukarı çıkarken kuş yukarı döner
    kus_donuslu = pygame.transform.rotate(kus_resmi, donus)
    ekran.blit(kus_donuslu, (kus_x, int(y)))


def boruyu_ciz(x, yukseklik):
    pygame.draw.rect(ekran, YESIL, (x, 0, boru_genislik, yukseklik))
    pygame.draw.rect(ekran, YESIL, (x, yukseklik + boru_bosluk, boru_genislik,
                                    YUKSEKLIK - yukseklik - boru_bosluk))


def carpisti_mi(kus_rect, boru_x, boru_yukseklik):
    if boru_x < kus_x + kus_genislik < boru_x + boru_genislik:
        if kus_rect.top <= boru_yukseklik or kus_rect.bottom >= boru_yukseklik + boru_bosluk:
            return True
    if kus_rect.bottom >= YUKSEKLIK:
        return True
    return False


def oyun_bitti_mesaji():
    yazi = yazi_tipi.render("Oyun Bitti", True, SIYAH)
    ekran.blit(yazi, yazi.get_rect(center=(GENISLIK // 2, YUKSEKLIK // 2)))
    tekrar = kucuk_yazi.render("Tekrar başlamak için R'ye bas", True, SIYAH)
    ekran.blit(tekrar,
               tekrar.get_rect(center=(GENISLIK // 2, YUKSEKLIK // 2 + 60)))


def geri_sayim():
    for i in range(3, 0, -1):
        ekran.fill(BEYAZ)
        yazi = yazi_tipi.render(str(i), True, KIRMIZI)
        ekran.blit(yazi, yazi.get_rect(center=(GENISLIK // 2, YUKSEKLIK // 2)))
        pygame.display.update()
        time.sleep(1)


def skor_goster():
    yazi = yazi_tipi.render(str(skor), True, SIYAH)
    ekran.blit(yazi, (GENISLIK // 2 - 20, 30))


def ana():
    global kus_y, kus_hizi, borular, oyun_bitti, oyun_basladi, skor

    FPS = 60
    calisiyor = True

    while calisiyor:
        if not oyun_basladi:
            geri_sayim()
            oyun_basladi = True

        saat.tick_busy_loop(FPS)

        for olay in pygame.event.get():
            if olay.type == pygame.QUIT:
                calisiyor = False
            if olay.type == pygame.KEYDOWN:
                if olay.key == pygame.K_SPACE and not oyun_bitti:
                    kus_hizi = zipla_gucu
                    # zipla_sesi.play()
                if olay.key == pygame.K_r and oyun_bitti:
                    # Sıfırla
                    kus_y = YUKSEKLIK // 2
                    kus_hizi = 0
                    borular = [{
                        "x":
                        GENISLIK,
                        "y":
                        random.randint(50, YUKSEKLIK - boru_bosluk - 100),
                        "skor_alindi":
                        False
                    }]
                    oyun_bitti = False
                    oyun_basladi = False
                    skor = 0

        if not oyun_bitti:
            kus_hizi += yercekimi
            kus_y += kus_hizi

            for boru in borular:
                boru["x"] -= boru_hizi

                if not boru[
                        "skor_alindi"] and boru["x"] + boru_genislik < kus_x:
                    skor += 1
                    boru["skor_alindi"] = True

            # Yeni boru üret
            if borular[-1]["x"] < GENISLIK - 300:
                borular.append({
                    "x":
                    GENISLIK,
                    "y":
                    random.randint(50, YUKSEKLIK - boru_bosluk - 100),
                    "skor_alindi":
                    False
                })

            # Boruları temizle
            borular = [b for b in borular if b["x"] + boru_genislik > 0]

            kus_rect = pygame.Rect(kus_x, kus_y, kus_genislik, kus_yukseklik)
            for boru in borular:
                if carpisti_mi(kus_rect, boru["x"], boru["y"]):
                    oyun_bitti = True
                    # carpma_sesi.play()
                    break

        ekran.fill(BEYAZ)

        kusu_ciz(kus_y, kus_hizi)

        for boru in borular:
            boruyu_ciz(boru["x"], boru["y"])

        skor_goster()

        if oyun_bitti:
            oyun_bitti_mesaji()

        pygame.display.update()

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    ana()

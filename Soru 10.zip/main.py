kelime = input("Kelime: ")
print(sum(harf in "aeıioöuüAEIİOÖUÜ" for harf in kelime))
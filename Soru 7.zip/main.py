sozluk = input("Bir sözcük girin: ")
harf = input("Bir harf girin: ")
print(sozluk.count(harf))